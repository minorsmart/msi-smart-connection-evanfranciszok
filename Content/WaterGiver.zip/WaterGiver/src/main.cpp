#include <Arduino.h>
#include "switchKaKu.h"
#define TRANSMITTERID1 13579
#define rfPin 25
#define RELAYPIN 33
#define MOISTPIN 36
#define LIGHTPIN 39

unsigned long lastTimeOfCheck = 0;

void checkWater()
{
  Serial.println("checking moist level");
  if (analogRead(MOISTPIN) < 100)
  {
    digitalWrite(RELAYPIN, HIGH);
    Serial.println("Pump On");
  }
  delay(1000);
  digitalWrite(RELAYPIN, LOW);
  Serial.println("Pump off");
}

void checkLight() {
  switchKaku(rfPin, TRANSMITTERID1, 1, 1, false, 3);
  // delay voor nagloei van lamp
  delay(100);
  Serial.println(analogRead(LIGHTPIN));
  if(analogRead(LIGHTPIN) < 1500)
    switchKaku(rfPin, TRANSMITTERID1, 1, 1, true, 3);  
}

void setup()
{
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(RELAYPIN, OUTPUT);
}

void loop()
{
  if (millis() - lastTimeOfCheck > 5000)
  {
    lastTimeOfCheck = millis();
    checkWater();
    checkLight();
  }
  // put your main code here, to run repeatedly:
}